package com.justeat.pizzaorder.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="Login1")
public class Login {
public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
public Login() {
	
	
}
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="username")
@NotEmpty(message="username Cannot be empty") 
String username;
@Column(name="username")
@NotEmpty(message="password Cannot be empty") 
String password;
}
