package com.justeat.pizzaorder.dao;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.justeat.pizzaorder.bean.*;
import com.justeat.pizzaorder.service.*;
public class CustomerDao {
	
	private	 SessionFactory sessionFactory;
	 public String verify(Login user) {
		   String p=null;
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  String hql="from login1 where username=:uname and password=:pwd";
		  Query query=session.createQuery(hql);
		  query.setParameter("uname",user.getUsername());
		  query.setParameter("pwd", user.getPassword());
	      List<String>s=query.getResultList();
		  for(String u:s) {
			  if(u.equals(user.getPassword())) {
			      p="success";
		  }else {
			  
			  p="failed";
		  }
		  }
		  session.save(user);
		  tx.commit();
		  session.close();
		return p; 
	  }
	 public int placeOrder(Customer cust,PizzaOrder order) {
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  order.setCustomerId(cust);
		  session.save(order);
		  int id=order.getOrderId();
		  System.out.println("pizzaid"+id);
		  tx.commit();
		  session.close();
		  return id;
	 }
}
