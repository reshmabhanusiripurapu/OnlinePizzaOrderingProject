package com.justeat.pizzaorder.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="customer1")
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="customerid")
private int customerId;
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="customername")
private String customerName;
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="address")
private String address;
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="phoneno")
private String phoneno;
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}

}
