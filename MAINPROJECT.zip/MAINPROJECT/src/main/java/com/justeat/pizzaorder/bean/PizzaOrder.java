package com.justeat.pizzaorder.bean;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="pizzaorder1")
public class PizzaOrder
{
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="orderid")
private int orderId;
@GeneratedValue(strategy=GenerationType.IDENTITY)
@ManyToOne(cascade=CascadeType.ALL)
@JoinColumn(name="customerid",unique=true)
@Column(name="customerid")
private Customer customerId;
public Customer getCustomerId() {
	return customerId;
}
public void setCustomerId(Customer customerId) {
	this.customerId = customerId;
}
@Column(name="totalPrice")
private int totalPrice;
public int getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(int totalPrice) {
	this.totalPrice = totalPrice;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
private String topping;
public String getTopping() {
	return topping;
}
public void setTopping(String topping) {
	this.topping = topping;
}
}
