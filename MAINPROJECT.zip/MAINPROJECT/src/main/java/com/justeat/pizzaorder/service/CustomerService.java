package com.justeat.pizzaorder.service;
import org.springframework.beans.factory.annotation.Autowired;

import com.justeat.pizzaorder.dao.CustomerDao;

import com.justeat.pizzaorder.bean.*;
public class CustomerService {
	@Autowired
	private CustomerDao custDAO;
    public String verify(Login user) {
			 String result= custDAO.verify(user); 
			  System.out.println("into Service");
			return result;
		}
		
	public int placeOrder(Customer cust,PizzaOrder order) {
		int basePrice=350;
		int totalPrice=0;
		if(order.getTopping().equals("capsicum"))
			totalPrice=basePrice+30;
		else if(order.getTopping().equals("mushroom"))
			totalPrice=basePrice+50;
		else if(order.getTopping().equals("jalapeno"))
			totalPrice=basePrice+70;
		else
		    totalPrice=basePrice+85;
        
	return totalPrice;
	}
		
		
}
