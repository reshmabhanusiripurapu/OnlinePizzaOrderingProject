package com.justeat.pizzaorder.controller;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.justeat.pizzaorder.bean.Login;
import com.justeat.pizzaorder.service.*;
import com.justeat.pizzaorder.bean.Customer;

import org.springframework.beans.factory.annotation.Autowired;
@Controller
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@RequestMapping("loginpage")  
    public String display(Model m)  
    {  
        m.addAttribute("login", new Login());  
        return "login";  
    }  
	@RequestMapping(value ="/view", method = RequestMethod.POST)
	 public String verify(@ModelAttribute("custlogin")Login user,Model m) {
		try {
			String res=customerService.verify(user);
			if(res.equals("success"))
				return "view";
			else
				return "login";
		}
		finally {
			System.out.println("Something went wrong");
		}
	}
	@RequestMapping("placeorder")  
    public String placing()  
    {   
        return "placeorder";  
    } 
	@RequestMapping(value="/orderplaced",method=RequestMethod.POST)
	public String getOrder(@RequestParam("topping") String topping,Customer cust,Model m) {
		m.addAttribute("cust", new Customer()); 
		return "success";
	}
	@RequestMapping("exit")  
    public String exit()  
    {   
        return "exit";  
    } 
}
